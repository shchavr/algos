class ExperimentData:
    """
    Структура для хранения данных эксперимента.
    """
    def __init__(self, length, counts):
        self.length = length
        self.counts = counts
